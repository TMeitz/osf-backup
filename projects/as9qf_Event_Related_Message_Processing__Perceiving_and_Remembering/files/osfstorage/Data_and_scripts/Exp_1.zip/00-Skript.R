# Auswertung Segmentierung Semantic MM
# last mod: 2015-10-15 mh

library(segmag)
library(stringr)
library(plyr)
library(ggplot2)
library(sciplot)
library(lme4)
library(lmerTest)
library(LMERConvenienceFunctions)
library(car)
library(ez)
library(PsychHelperFunctions)
library(tidyr)
library(readr)

cbbPalette <- c("#000000", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

dat <- data.frame(list("participant" = 1,"rt" = 1))
dat <- dat[0,]

wd <- getwd()
paths <- dir(path = wd, pattern = ".csv", full = T)
dat.all <- lapply(paths, read.csv, header = T, as.is = T)


for (i in 1:length(dat.all))
{
  print(paste("Verarbeite Datei: ",paths[i]))
  dat.raw <- data.frame(dat.all[i])
  dat.raw <- dat.raw[!is.na(dat.raw$key_resp_2.rt),]
  dat.raw <- dat.raw[dat.raw$key_seg.keys != "None",]
  
  for (j in 1:length(dat.raw$movie))
  {
    raw.rt <-
      strsplit(sub("\\]", "", sub("\\[", "", dat.raw$key_seg.rt[j])), ", ")
    raw.key <-
      strsplit(gsub("'", "", sub(
        "\\]", "", sub("\\[", "", dat.raw$key_seg.keys[j])
      )), ", ")
    if (sum(raw.key[[1]] != "space") != 0)
    {
      stop("Tastendruck != space. Rohdaten pruefen!")
    }
    if (length(raw.key[[1]]) != length(raw.rt[[1]]))
    {
      stop("Anzahl Tastendruecke != Anzahl RTs: Rohdaten pruefen!")
    }
    
    tmp <-
      data.frame(
        list(
          "participant" = dat.raw$participant[j], "rt" = as.numeric(raw.rt[[1]])
        ),movie = dat.raw$movie[j],grain = dat.raw$instruction[j],condition=dat.raw$condition[j]
      )
    dat <- rbind(dat, tmp)
  }
}


# Neue AV V Variable einfuehren
dat$V_AV <- "AV"
dat[str_detect(dat$movie,"_V"),]$V_AV <- "V"

dat$participant <- factor(dat$participant)

# Movie Variable umbenennen

unique(dat$movie)
dat$movie <- as.character(dat$movie)
dat[str_detect(dat$movie,pattern = "Easy"),]$movie <- "Easy"
dat[str_detect(dat$movie,pattern = "Marnie"),]$movie <- "Marnie"
dat[str_detect(dat$movie,pattern = "Mann"),]$movie <- "Mann"
dat[str_detect(dat$movie,pattern = "Shining"),]$movie <- "Shining"
dat[str_detect(dat$movie,pattern = "Hellboy"),]$movie <- "Hellboy"
dat[str_detect(dat$movie,pattern = "Romeo"),]$movie <- "Romeo"
dat[str_detect(dat$movie,pattern = "Full"),]$movie <- "Full"
dat[str_detect(dat$movie,pattern = "Taxi"),]$movie <- "Taxi"
dat[str_detect(dat$movie,pattern = "Oceans"),]$movie <- "Ocean"
dat[str_detect(dat$movie,pattern = "300"),]$movie <- "300"

####
# ACHUTNG: FEHLER: 
# funktioniert hat nur die condition==1, bei condition==2 wurde auf einigen 
# Rechnern alles AV präsentiert.
# Betroffen sind folgende VPn: 30,31,34,38,39 und alle < 24 (in condition 2)
# diese müssen ausgeschlossen werden:

dat$filter <- 0
dat[dat$condition==2&as.numeric(as.character(dat$participant))<24,]$filter <- 1
dat[as.numeric(as.character(dat$participant))==1,]$filter <- 1 # Vor-VP
dat[as.numeric(as.character(dat$participant))==30,]$filter <- 1
dat[as.numeric(as.character(dat$participant))==31,]$filter <- 1
dat[as.numeric(as.character(dat$participant))==34,]$filter <- 1
dat[as.numeric(as.character(dat$participant))==38,]$filter <- 1
dat[as.numeric(as.character(dat$participant))==39,]$filter <- 1

dat <- dat[dat$filter!=1,]
dat$participant <- factor(dat$participant)

plyr::count(dat,vars=c("participant","condition"))
plyr::count(dat,vars=c("condition","participant"))
plyr::count(dat,vars=c("V_AV"))
plyr::count(dat,vars=c("participant"))

#############
# Datei mit cuts laden
#############

cuts <- read.csv("cuts.txt")

# time_min und time_max hinzufuegen

cuts$time_min <- 0
cuts$time_max <- NA
cuts[cuts$movie=="300",]$time_max <- 5*60+25
cuts[cuts$movie=="Mann",]$time_max <- 5*60+38
cuts[cuts$movie=="Marnie",]$time_max <- 4*60+58
cuts[cuts$movie=="Hellboy",]$time_max <- 4*60+58
cuts[cuts$movie=="Taxi",]$time_max <- 5*60+12
cuts[cuts$movie=="Romeo",]$time_max <- 4*60+58
cuts[cuts$movie=="Shining",]$time_max <- 4*60+53
cuts[cuts$movie=="Ocean",]$time_max <- 5*60+2
cuts[cuts$movie=="Full",]$time_max <- 5*60+4
cuts[cuts$movie=="Easy",]$time_max <- 5*60+3

# Create segmag objects

segmag_names <- data.frame(segmag_names=NA)
segmag_names <- segmag_names[!is.na(segmag_names$segmag_names),]

for (i in unique(dat$movie))
  {
    print(i)
  for (j in unique(dat[dat$movie==i,]$V_AV))
  {
    tmp <- segmag(participant,rt,data=dat[dat$movie==i&dat$V_AV==j,],time_min = 0,time_max = cuts[cuts$movie==i,]$time_max[1],
                  gauss_offset = -.8,gauss_sd = .8)
    assign(paste0("segmag_",i,"_",j),tmp)
    segmag_names <- rbind(segmag_names,paste0("segmag_",i,"_",j))
  }   
}

# Add segmentation magnitude

tmp <- data.frame(movie=NA,
                   V_AV=NA,
                   time=NA,
                   dim_change=NA,
                   segmentation_magnitude=NA)
tmp <- tmp[-1,]

for (i in unique(dat$movie))
{
  print(i)
  for (j in unique(dat[dat$movie==i,]$V_AV))
  {
#    print(j)
    for(k in unique(cuts[cuts$movie==i,]$sec))
    {
      segmag_tmp <- get(paste0("segmag_",i,"_",j))
#      print(paste0("segmag_",i,"_",j))
      tmp <- rbind(tmp,
                   data.frame(movie=i,
                        V_AV=j,
                        time=k,
                        dim_change=cuts[cuts$movie==i&cuts$sec==k,]$dim_change,
                        segmentation_magnitude=segmag_tmp$data[segmag_tmp$data$time==k,]$segmentation_magnitude)
      )
    }
  }   
}


tmp$Change <- NA
tmp[tmp$dim_change==0,]$Change <- "Within Scene"
tmp[tmp$dim_change==1,]$Change <- "Between Scene"

tmp$Modality <- NA
tmp[tmp$V_AV=="V",]$Modality <- "Visual"
tmp[tmp$V_AV=="AV",]$Modality <- "Audiovisual"

# Wie viele between und within scene changes im Schnitt pro Clip?

dat_mean_changes <- plyr::count(tmp,vars=c("Change","movie"))
ddply(dat_mean_changes,.(Change),summarize,mean_changes=mean(freq),sd_changes=sd(freq))

# Plots und Analysen

dat_agg <- ddply(tmp,.(Change,Modality,movie),summarize,segmentation_magnitude=mean(segmentation_magnitude))
summary(aov(segmentation_magnitude~Change*Modality+Error(movie/(Change*Modality)),data=dat_agg))

res <- ezANOVA(
  data=dat_agg,
  dv=segmentation_magnitude,
  within = .(Change,Modality),
  wid = movie,
  detailed = T
)

ezANOVA.pes(res)

par(mfrow=c(1,1),cex=1.6)
bargraph.CI(Modality,segmentation_magnitude,group=Change,data=dat_agg,
            legend=T,ylab="Segmentation Magnitude",xlab="Modality",x.leg=3,
            ylim=c(0,2))

# Effektstärke berechnen

cohen_d <- function(mean1,mean2,pooled_sd)
{
  (mean1-mean2)/pooled_sd
}

cohen_f <- function(cohen_d)
{
  cohen_d*.5
}

ddply(dat_agg,.(Change),summarize,mean_segmentation_magnitude=mean(segmentation_magnitude))
sd(dat_agg$segmentation_magnitude)

cohen_d(0.9005351,0.3217276,0.3907803)
cohen_f(1.481158)

ddply(dat_agg,.(Modality),summarize,mean_segmentation_magnitude=mean(segmentation_magnitude))
sd(dat_agg$segmentation_magnitude)

cohen_d(0.6543895,0.5678731,0.3907803)
cohen_f(0.221394)


# Export data for JASP analysis
dat_agg$Change <- str_replace(dat_agg$Change," ","_")
dat_jasp <- dat_agg %>% unite(Change_Modality,Change,Modality) %>% spread(Change_Modality,segmentation_magnitude) 

write_csv(dat_jasp,"dat_jasp.csv")
