library(gridExtra)


grid.arrange(plot_modality, plot_mask, plot_mask_modality, nrow=1)

g <- arrangeGrob(plot_modality, plot_mask, plot_mask_modality, nrow=1)
ggsave("all_exps.tiff", g, width = 33, height = 11,units = "cm")
