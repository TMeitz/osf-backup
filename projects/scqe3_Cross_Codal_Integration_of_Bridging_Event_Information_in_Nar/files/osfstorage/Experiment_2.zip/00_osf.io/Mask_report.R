# Auswertung BSc Arbeit Maria Oberbeck SoSe 2017

library(plyr)
library(tidyverse)
library(sciplot)
library(lme4)
library(car)
library(lmerTest)
library(effects)

#- Read data

paths <- dir(pattern = ".csv", full = T) 
dat <- data.frame()
for(i in seq_along(paths))
{
  print(paths[i])
  tmpdat <- read.csv(paths[i])
  if (length(dat) > 0 && !identical(names(dat),names(tmpdat)))
  {
    stop("Spaltennamen stimmen nicht - Fehler! Daten pruefen!")
  }
  dat <- rbind(dat,tmpdat)
}

# VP Variable faktorisieren
dat$participant <- factor(dat$participant)

# Wie viele VPn?
length(unique(dat$participant))


# Nur relevante Bedingungen auswerten
dat <- dat[dat$condition %in% c("visual_be","mask_be","no_be"),]
dat$condition <- factor(dat$condition)

# Bedingungen umbenennen
dat$image_type <- revalue(dat$image_type, replace = c("bridging_vis" = "bridging","bridging_mask" = "bridging"))
dat$vt <- dat$key_resp_2.rt

# Faktor  neu sortieren
dat$condition <- factor(dat$condition, levels = c("no_be","visual_be","mask_be"))

# Kontrolle
# ddply(dat,.(story, condition, image_type), summarise,mean_vt = mean(vt), N = length(vt))
# ddply(dat,.(condition, image_type), summarise,mean_vt = mean(vt), N = length(vt))

# Data trimming (wie bei Magliano et al., 2016)
# Gültige Daten: filter == 1

# Wie viele Trials fallen aufgrund der unterschiedlichen Kriterien weg?

total_trials <- length(dat$vt)

# Unteres cut-off:
length(dat[dat$vt < .480,]$vt)
length(dat[dat$vt < .480,]$vt)/total_trials

# Oberes cut-off:
length(dat[dat$vt > 20,]$vt)
length(dat[dat$vt > 20,]$vt)/total_trials

# Filter definieren
dat <- dat[dat$vt >= .480,]
dat <- dat[dat$vt <= 20,]

dat$filter <- 0

threshold_no_be <-
  mean(dat[dat$condition == "no_be", ]$vt) + 
  3 * sd(dat[dat$condition == "no_be", ]$vt)
threshold_mask_be <-
  mean(dat[dat$condition == "mask_be", ]$vt) + 
  3 * sd(dat[dat$condition == "mask_be", ]$vt)
threshold_visual_be <-
  mean(dat[dat$condition == "visual_be", ]$vt) + 
  3 * sd(dat[dat$condition == "visual_be", ]$vt)

dat[dat$condition == "no_be" & dat$vt <= threshold_no_be,]$filter <- 1
dat[dat$condition == "mask_be" & dat$vt <= threshold_mask_be,]$filter <- 1
dat[dat$condition == "visual_be" & dat$vt <= threshold_visual_be,]$filter <- 1

xtabs(~filter + condition, dat)

# VP Ausschluss
# Bei welcher VP mussten mehr als 25% aller Durchgänge ausgeschlossen werden?
xtabs(filter/48 ~ participant, dat[dat$filter == 1,])


# Plot

dat_plot <- 
  ddply(dat[dat$filter == 1,],
        .(condition, image_type), 
        summarise,
        mean_vt = mean(vt), se_vt = se(vt))

pd <- position_dodge(0.3)

ggplot(dat_plot, aes(x = image_type, y = mean_vt, fill = condition)) +
  geom_point( aes(color = condition), position = pd) +
  geom_line(aes(group = condition, color = condition), position = pd) +
  geom_errorbar(aes(ymax = mean_vt + se_vt, ymin = mean_vt - se_vt, color = condition),position = pd, width =.2) +
  theme_bw(base_size = 16) +
  theme(legend.position = "top")

# Daten für Analyse aggregieren

dat_aov <- 
  ddply(dat[dat$image_type != "bridging" & dat$filter == 1,],
        .(participant, condition, image_type), 
        summarise,
        mean_vt = mean(vt))

summary(aov(mean_vt ~ condition * image_type + 
              Error(participant / (condition * image_type)),
            data = dat_aov))

pairwise.t.test(x = dat_aov$mean_vt, 
                g = paste(dat_aov$image_type,dat_aov$condition), 
                p.adjust.method = "none")

# HE für Condition genauer untersuchen

dat_posthoc_condition <- 
  ddply(dat[dat$image_type != "bridging" & dat$filter == 1,],
        .(participant, condition), 
        summarise,
        mean_vt = mean(vt))

pairwise.t.test(x = dat_aov$mean_vt, 
                g = dat_aov$condition, 
                p.adjust.method = "none")

# Korrelation vt mask (bridging ~ inference_0)
dat_cor <- ddply(dat[dat$condition == "mask_be"  & (dat$image_type == "bridging" | dat$image_type == "inference_0"),],
                 .(participant, image_type), summarise, mean_vt = mean(key_resp_2.rt))

dat_cor <- spread(dat_cor,image_type,mean_vt)

plot(dat_cor$inference_0,dat_cor$bridging)
abline(lm(dat_cor$bridging ~ dat_cor$inference_0))

cor.test(dat_cor$bridging, dat_cor$inference_0)


# lmer Ansatz

library(lme4)
library(car)
library(lmerTest)
library(effects)

mod <- lmer(vt ~ condition * image_type + 
              (condition | participant) + 
              (condition | story), 
            data = dat[dat$image_type != "bridging",])

Anova(mod)
summary(mod)

allEffects(mod)
plot(allEffects(mod), lwd = 0)


