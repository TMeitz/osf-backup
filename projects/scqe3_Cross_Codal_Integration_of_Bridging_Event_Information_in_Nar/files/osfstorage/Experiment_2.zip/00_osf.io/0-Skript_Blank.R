# ViewingTime Mask/Blank
# Experiment 2 in paper

library(plyr)
library(tidyverse)
library(sciplot)
library(lme4)
library(car)
library(lmerTest)
library(effects)
library(gridExtra)

#- Read data

paths <- dir(pattern = ".csv", full = T) 
dat <- data.frame()
for(i in seq_along(paths))
{
  print(paths[i])
  tmpdat <- read.csv(paths[i])
  if (length(dat) > 0 && !identical(names(dat),names(tmpdat)))
  {
    stop("Spaltennamen stimmen nicht - Fehler! Daten pruefen!")
  }
  dat <- rbind(dat,tmpdat)
}

# Load additional participants

setwd("set_2/")

paths <- dir(pattern = ".csv", full = T) 
dat_add <- data.frame()
for(i in seq_along(paths))
{
  print(paths[i])
  tmpdat <- read.csv(paths[i])
  if (length(dat_add) > 0 && !identical(names(dat_add),names(tmpdat)))
  {
    stop("Spaltennamen stimmen nicht - Fehler! Daten pruefen!")
  }
  dat_add <- rbind(dat_add,tmpdat)
}

dat_add$participant <- dat_add$participant + 1000

# Arbeitsverz. zurücksetzen
setwd("../")

# Datensätze zusammenführen

dat <- rbind(dat, dat_add)

# VP Variable faktorisieren
dat$participant <- factor(dat$participant)

# Wie viele VPn?
length(unique(dat$participant))


# Nur relevante Bedingungen auswerten
dat <- dat[dat$condition %in% c("visual_be","mask_be","no_be"),]
dat$condition <- factor(dat$condition)

# Bedingungen umbenennen
dat$image_type <- revalue(dat$image_type, replace = c("bridging_vis" = "Bridging","bridging_mask" = "Bridging"))
dat$image_type <- revalue(dat$image_type, replace = c("inference_0" = "End State","inference_1" = "End State + 1"))
dat$condition <- revalue(dat$condition, replace = c("no_be" = "Absent","visual_be" = "Picture", "mask_be" = "Blank"))

dat$vt <- dat$key_resp_2.rt

# Faktor  neu sortieren
dat$condition <- factor(dat$condition, levels = c("Absent","Picture","Blank"))

# Kontrolle
ddply(dat,.(story, condition, image_type), summarise,mean_vt = mean(vt), N = length(vt))
ddply(dat,.(condition, image_type), summarise,mean_vt = mean(vt), N = length(vt))

# Data trimming (wie bei Magliano et al., 2016)
# Gültige Daten: filter == 1

# Wie viele Trials fallen aufgrund der unterschiedlichen Kriterien weg?

total_trials <- length(dat$vt)


# Unteres cut-off:
length(dat[dat$vt < .480,]$vt)
length(dat[dat$vt < .480,]$vt)/total_trials

# Oberes cut-off:
length(dat[dat$vt > 20,]$vt)
length(dat[dat$vt > 20,]$vt)/total_trials

# Filter definieren
dat <- dat[dat$vt >= .480,]
dat <- dat[dat$vt <= 20,]

dat$filter <- 0

threshold_no_be <-
  mean(dat[dat$condition == "Absent", ]$vt) + 
  3 * sd(dat[dat$condition == "Absent", ]$vt)
threshold_mask_be <-
  mean(dat[dat$condition == "Blank", ]$vt) + 
  3 * sd(dat[dat$condition == "Blank", ]$vt)
threshold_visual_be <-
  mean(dat[dat$condition == "Picture", ]$vt) + 
  3 * sd(dat[dat$condition == "Picture", ]$vt)

dat[dat$condition == "Absent" & dat$vt <= threshold_no_be,]$filter <- 1
dat[dat$condition == "Blank" & dat$vt <= threshold_mask_be,]$filter <- 1
dat[dat$condition == "Picture" & dat$vt <= threshold_visual_be,]$filter <- 1

xtabs(~filter + condition, dat)


# Wie viele Trials fallen aufgrund des normativen Trimmings raus?
length(dat[dat$filter == 0,]$story)
length(dat[dat$filter == 0,]$story)/total_trials

# VP Ausschluss
# Bei welcher VP mussten mehr als 25% aller Durchgänge ausgeschlossen werden? --> Bei keiner

ddply(dat,.(participant), summarize, out = sum(filter)/length(vt))

dat$participant <- factor(dat$participant)

# lmer Ansatz

dat_lmer <- dat[dat$image_type != "Bridging" & dat$filter == 1, 
                c("vt", "participant", "condition", "image_type", "story")]


mod <- lmer(log(vt) ~ condition * image_type + 
              (condition | participant) + 
              (condition | story), 
            data = dat_lmer, REML = TRUE)

Anova(mod)
summary(mod)

difflsmeans(mod, test.effs = "condition:image_type", adjust = "tukey")


# Plot

dat_plot <- 
  ddply(dat[dat$filter == 1,],
        .(condition, image_type), 
        summarise,
        mean_vt = mean(vt), se_vt = se(vt))

pd <- position_dodge(0)

plot_mask <- 
  ggplot(dat_plot, aes(x = image_type, y = mean_vt)) +
  geom_point( aes(color = condition)) +
  geom_line(aes(group = condition, color = condition)) +
  geom_errorbar(aes(ymax = mean_vt + se_vt, ymin = mean_vt - se_vt, color = condition), width =.2) +
  theme_bw(base_size = 16) +
  theme(legend.title=element_blank()) +
  theme(legend.position = "top") +
  labs(color = 'Bridging Event') +
  xlab('Image Sequence') +
  ylab('Viewing Time [sec]') +
  coord_cartesian(ylim = c(1,4.5))+
  scale_colour_manual(values=c("#000000", "#E69F00", "#009E73"))+
  labs(title="Experiment 2")


ggsave("mask.pdf", plot = plot_mask, width = 15, height = 10, units = "cm")

