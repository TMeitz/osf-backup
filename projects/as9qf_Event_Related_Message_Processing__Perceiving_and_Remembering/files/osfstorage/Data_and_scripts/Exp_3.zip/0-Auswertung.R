# Massive memory, situation model changes (visual vs. audio-visual)
#
# 2 x 2 Design (within-subjects)
# 1. UV: Change (within scene change vs. between scene change)
# 2. UV: Modality (visual vs. audiovisual)
#
# last modification: 2015-10-26 mh

library(ggplot2)
library(sciplot)
library(plyr)
library(ez)
library(PsychHelperFunctions)
library(tidyr)

# ezWrapper einlesen

ezANOVA.pes <- function (ezANOVAResult)
{
  if (is.null(ezANOVAResult$ANOVA$SSn) | is.null(ezANOVAResult$ANOVA$SSd))
  {
    stop("ezANOVA muss mit dem Parameter 'detailed=T' ausgeführt werden.")
  }
  
  ezANOVAResult$ANOVA$pes <- ezANOVAResult$ANOVA$SSn/(ezANOVAResult$ANOVA$SSn+ezANOVAResult$ANOVA$SSd)
  
  return(ezANOVAResult)
}


# load audio-visual data

wd <- getwd()

paths <- dir(path = wd, pattern = ".txt", full = T) 
dat.raw <- lapply(paths, read.csv2)

# Generate data frame 
dat <- data.frame(dat.raw[1])

for (i in 2:length(dat.raw))
{
  dat <- rbind(dat,data.frame(dat.raw[i]))
}

dat$nCuts <- as.numeric(dat$nCuts)
dat$nCuts[dat$nCuts==1] <- "Within Scene"
dat$nCuts[dat$nCuts==2] <- "Between Scene"

dat$modality <- as.numeric(dat$modality)
dat$modality[dat$modality==1] <- "Visual"
dat$modality[dat$modality==2] <- "Audiovisual"

aggregate(accuracy~nCuts+modality,dat,mean)
aggregate(accuracy~nCuts+modality,dat,sd)

# Wie viele Trials pro VP?
ddply(dat, .(vp), summarize, N = length(vp))

# Welche Filme?
ddply(dat, .(clip), summarize, N = length(vp))


# Berechnung von Proportion Correct
dat$PC <- NA
dat$PC <- ifelse(dat$keyCorrect==dat$keyPressed,1,0)

dat$movie_clip <- paste0(dat$movie,dat$clip,dat$nCuts)
unique(dat$movie_clip)

write.csv(dat,"dat.csv")

# Signal detection analysis

data.tar <- dat[dat$target=="1.0",]
data.tar.aggr <- aggregate(data.tar$accuracy, list(data.tar$vp, data.tar$nCuts,data.tar$modality), mean)
names(data.tar.aggr)<-c("vp", "nCuts","modality","HI")

data.dis <- dat[dat$target=="0.0",]
data.dis.aggr <- aggregate(data.dis$accuracy, list(data.dis$vp, data.dis$nCuts,data.dis$modality), mean)
names(data.dis.aggr)<-c("vp", "nCuts","modality","CR")

data.sdt <- merge(data.tar.aggr, data.dis.aggr)
data.sdt$FA <- 1 - data.sdt$CR

#data.sdt[data.sdt$FA==0,]$FA <- 0.05
#data.sdt[data.sdt$HI==1,]$HI <- 0.95

data.sdt$dprime <- qnorm(data.sdt$HI) - qnorm(data.sdt$FA)
data.sdt$c <- -0.5*(qnorm(data.sdt$HI) + qnorm(data.sdt$FA))

#- klass ANOVA

# F1-ANOVA: Proportion correct
dat_agg <- ddply(dat,.(vp,nCuts,modality),summarize,mean_PC=mean(PC))
ddply(dat,.(nCuts,modality),summarize,mean_PC=mean(PC))
summary(aov(mean_PC~factor(nCuts)*modality+Error(factor(vp)/(factor(nCuts)*modality)),data=dat_agg))

res <- ezANOVA(
  data=dat_agg,
  dv=mean_PC,
  within = .(nCuts,modality),
  wid = vp,
  detailed = T
)

ezANOVA.pes(res)

# F2-ANOVA: Proportion correct
dat_agg <- ddply(dat,.(movie_clip,nCuts,modality),summarize,mean_PC=mean(PC))
dat_agg$movie_clip <- tolower(dat_agg$movie_clip)
dat_agg$movie_clip <- str_replace_all(dat_agg$movie_clip,"[a-z]","")

unique(dat_agg$movie_clip)
summary(aov(mean_PC~factor(nCuts)*modality+Error(factor(movie_clip)/(factor(nCuts)*modality)),data=dat_agg))
res <- ezANOVA(
  data=dat_agg,
  dv=mean_PC,
  within = .(nCuts,modality),
  wid = movie_clip,
  detailed = T
)

ezANOVA.pes(res)

# SDT measures
ddply(data.sdt,.(nCuts,modality),summarize,mean_dprime=mean(dprime),sd_dprime=sd(dprime))

summary(aov(dprime~factor(nCuts)*modality+Error(factor(vp)/(factor(nCuts)*modality)),data=data.sdt))

res <- ezANOVA(
  data=data.sdt,
  dv=dprime,
  within = .(nCuts,modality),
  wid = vp,
  detailed = T
)

ezANOVA.pes(res)

summary(aov(c~factor(nCuts)*modality+Error(factor(vp)/(factor(nCuts)*modality)),data=data.sdt))

res <- ezANOVA(
  data=data.sdt,
  dv=c,
  within = .(nCuts,modality),
  wid = vp,
  detailed = T
)

ezANOVA.pes(res)

dat_agg <- ddply(dat,.(vp,nCuts,modality),summarize,mean_PC=mean(PC))

par(mfrow=c(1,3))
bargraph.CI.within(modality,mean_PC,group=nCuts,data=dat_agg,sid=vp,legend=T,ylab="Proportion Correct",xlab="Modality",ylim=c(.6,.8),x.leg=1,y.leg=.769,main="Proportion Correct")
text(x=2,y=.77,"Change")
bargraph.CI.within(modality,dprime,group=nCuts,data=data.sdt,sid=vp,legend=F,ylab="Sensitivity (d')",xlab="Modality",ylim=c(0,1.6),x.leg=3,y.leg=1.5,main="Sensitivity")
bargraph.CI.within(modality,c,group=nCuts,data=data.sdt,sid=vp,legend=F,ylab="Response Bias (c)",xlab="Modality",ylim=c(0,.5),x.leg=1.5,main="Response Bias")

par(mfrow=c(1,1))
bargraph.CI.within(modality,mean_PC,group=nCuts,data=dat_agg,sid=vp,legend=T,ylab="Proportion Correct",xlab="Modality",ylim=c(.6,.8),x.leg=4,y.leg=.769)
text(x=4.3,y=.77,"Change")




# Dimension change Analyse
# Dimension change Daten laden

# Results
# No correlations between the number of dimension changes and memory performance as well as between each separate change and performance

dat.dc <- read.csv("DC_Ton.csv",sep=",")
head(dat.dc)
head(dat)
dat.dc$movie <- substr(dat.dc$clip,3,4)
dat.dc$clip2 <- substr(dat.dc$clip,9,10)
dat.dc$nCuts <- substr(dat.dc$clip,6,6)
dat.dc[dat.dc$nCuts=="D",]$nCuts <- "Between Scene"
names(dat.dc)[1] <- c("clip2")
names(dat.dc)[8] <- c("clip")

head(dat.dc)
head(dat)

dat.dc[,1] <- NULL

#- Merge Datenframe für die Analyse der Dimension changes
dat$movie <- as.numeric(as.character(dat$movie))
dat$clip <- as.numeric(as.character(dat$clip))

dat.dc$movie <- as.numeric(as.character(dat.dc$clip))
dat.dc$clip <- as.numeric(as.character(dat.dc$clip2))

tmp <- merge(dat,dat.dc,by=c("movie","clip","nCuts"))

tmp$num_dim_changes <- tmp$location+tmp$character+tmp$time+tmp$action
tmp$location <- ifelse(tmp$location==0,"w/o","w/")
tmp$character <- ifelse(tmp$character==0,"w/o","w/")
tmp$time <- ifelse(tmp$time==0,"w/o","w/")
tmp$action <- ifelse(tmp$action==0,"w/o","w/")
tmp$soundtrack <- ifelse(tmp$soundtrack==0,"continuous","interrupted")
tmp$language <- ifelse(tmp$language==0,"no language","language")

# Descriptives

xtabs(~num_dim_changes,data=tmp[tmp$vp==1,])
xtabs(~location,data=tmp[tmp$vp==1,])
xtabs(~character,data=tmp[tmp$vp==1,])
xtabs(~time,data=tmp[tmp$vp==1,])
xtabs(~action,data=tmp[tmp$vp==1,])
xtabs(~soundtrack,data=tmp[tmp$vp==1,])
xtabs(~language,data=tmp[tmp$vp==1,])

tmp_agg <- aggregate(accuracy~vp+num_dim_changes,data=tmp,mean)
cor.test(tmp_agg$num_dim_changes,tmp_agg$accuracy)
p1 <- ggplot(tmp_agg, aes(x = num_dim_changes, y = accuracy)) +
  geom_point(position = "jitter") +
  theme_classic(base_size=20)+
  geom_smooth(method="lm")
p1

tmp_agg <- aggregate(accuracy~vp+location,tmp,mean)
t.test(tmp_agg$accuracy~tmp_agg$location,paired=T)
p2 <- ggplot(tmp_agg, aes(x = location, y = accuracy)) +
  geom_point(position = "jitter") +
  theme_classic(base_size=20)

tmp_agg <- aggregate(accuracy~vp+character,tmp,mean)
t.test(tmp_agg$accuracy~tmp_agg$character,paired=T)
p3 <- ggplot(tmp_agg, aes(x = character, y = accuracy)) +
  geom_point(position = "jitter") +
  theme_classic(base_size=20)

tmp_agg <- aggregate(accuracy~vp+time,tmp,mean)
t.test(tmp_agg$accuracy~tmp_agg$time,paired=T)
p4 <- ggplot(tmp_agg, aes(x = time, y = accuracy)) +
  geom_point(position = "jitter") +
  theme_classic(base_size=20)

tmp_agg <- aggregate(accuracy~vp+action,tmp,mean)
t.test(tmp_agg$accuracy~tmp_agg$action,paired=T)
p5 <- ggplot(tmp_agg, aes(x = action, y = accuracy)) +
  geom_point(position = "jitter") +
  theme_classic(base_size=20)

tmp_agg <- aggregate(accuracy~vp+soundtrack,tmp,mean)
t.test(tmp_agg$accuracy~tmp_agg$soundtrack,paired=T)
p6 <- ggplot(tmp_agg, aes(x = soundtrack, y = accuracy)) +
  geom_point(position = "jitter") +
  theme_classic(base_size=20)

library(gridExtra)
grid.arrange(p1,p2,p3,p4,p5,p6)


# Export data for JASP analysis
dat_agg$Change <- str_replace(dat_agg$nCuts," ","_")
dat_agg$Modality <- dat_agg$modality
dat_agg$nCuts <- NULL
dat_agg$modality <- NULL
dat_jasp <- dat_agg %>% unite(Change_Modality,Change,Modality) %>% spread(Change_Modality,mean_PC) 

write_csv(dat_jasp,"dat_jasp.csv")

