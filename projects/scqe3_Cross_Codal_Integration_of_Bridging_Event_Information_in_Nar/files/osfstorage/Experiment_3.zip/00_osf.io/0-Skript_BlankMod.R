# ViewingTime Mask Modality
# Experiment 3 in paper

library(plyr)
library(tidyverse)
library(sciplot)
library(lme4)
library(car)
library(lmerTest)
library(effects)
library(stringr)
library(gridExtra)

#- Read data

paths <- dir(pattern = ".csv", full = T) 
dat <- data.frame()
for(i in seq_along(paths))
{
  print(paths[i])
  tmpdat <- read.csv(paths[i])
  if (length(dat) > 0 && !identical(names(dat),names(tmpdat)))
  {
    stop("Spaltennamen stimmen nicht - Fehler! Daten pruefen!")
  }
  dat <- rbind(dat,tmpdat)
}

# VP Variable faktorisieren
dat$participant <- factor(dat$participant)

# Wie viele VPn?
length(unique(dat$participant))

# VP Statistik

# Nur relevante Bedingungen auswerten
dat <- dat[dat$condition %in% c("visual_be","text_be","mask"),]
dat$condition <- factor(dat$condition)

# Bedingungen umbenennen
dat$image_type <- revalue(dat$image_type, replace = c("bridging_vis" = "Bridging","bridging_text" = "Bridging","bridging_mask" = "Bridging"))
dat$image_type <- revalue(dat$image_type, replace = c("inference_0" = "End State","inference_1" = "End State + 1"))
dat$condition <- revalue(dat$condition, replace = c("mask" = "Blank","visual_be" = "Picture", "text_be" = "Text"))
dat$vt <- dat$key_resp_2.rt

# Faktor  neu sortieren
dat$condition <- factor(dat$condition, levels = c("Blank","Picture","Text"))

# Kontrolle
ddply(dat,.(story, condition, image_type), summarise,mean_vt = mean(vt), N = length(vt))
ddply(dat,.(condition, image_type), summarise,mean_vt = mean(vt), N = length(vt))


# Data trimming (wie bei Magliano et al., 2016)
# Gültige Daten: filter == 1

# Wie viele Trials fallen aufgrund der unterschiedlichen Kriterien weg?

total_trials <- length(dat$vt)


# Unteres cut-off:
length(dat[dat$vt < .480,]$vt)
length(dat[dat$vt < .480,]$vt)/total_trials

# Oberes cut-off:
length(dat[dat$vt > 20,]$vt)
length(dat[dat$vt > 20,]$vt)/total_trials

# Filter definieren
dat <- dat[dat$vt >= .480,]
dat <- dat[dat$vt <= 20,]

dat$filter <- 0

threshold_no_be <-
  mean(dat[dat$condition == "Blank", ]$vt) + 
  3 * sd(dat[dat$condition == "Blank", ]$vt)
threshold_text_be <-
  mean(dat[dat$condition == "Text", ]$vt) + 
  3 * sd(dat[dat$condition == "Text", ]$vt)
threshold_visual_be <-
  mean(dat[dat$condition == "Picture", ]$vt) + 
  3 * sd(dat[dat$condition == "Picture", ]$vt)

dat[dat$condition == "Blank" & dat$vt <= threshold_no_be,]$filter <- 1
dat[dat$condition == "Text" & dat$vt <= threshold_text_be,]$filter <- 1
dat[dat$condition == "Picture" & dat$vt <= threshold_visual_be,]$filter <- 1

# Wie viele trials werden aufgrund des normativen Trimmings ausgeschlossen?

length(dat[dat$filter == 0,]$vt)
length(dat[dat$filter == 0,]$vt)/total_trials


# VP Ausschluss
# Bei welcher VP mussten mehr als 25% aller Durchgänge ausgeschlossen werden?

ddply(dat,.(participant), summarize, out = sum(filter)/length(vt))


dat$participant <- factor(dat$participant)

# # Daten rausschreiben
# dat_vt <- dat[dat$condition == "Text" & dat$image_type == "End State",]
# dat_vt <- ddply(dat_vt, .(file), summarise, vt = mean(vt))
# dat_vt$file <- as.character(dat_vt$file)
# dat_vt <- dat_vt[order(dat_vt$file),]
# write_csv(dat_vt,"dat_vt.txt")

dat_text <- unique(dat[,c("participant","story","condition","text")])
dat_text$order <- c(1:nrow(dat_text))
dat_text$story <- as.numeric(as.character(dat_text$story))


texts <- c("Junge und Hund stolpern", "Junge schwingt Netz und Hund springt zu Frosch", "Junge und Hund gehen weg",
           "Junge zieht an Angel", "Hund taucht auf", "Junge hält Schildkröte und Hund weint",
           "Frosch springt weg", "Frosch versteckt sich im Korb", "Frosch hüpft in Kinderwagen",
           "Junge öffnet Paket und alle schauen hinein", "Großer Frosch tritt kleinen Frosch", "Alle gehen",
           "Frosch klettert aus Glas", "Maulwurf beißt", "Junge und Hund fallen",
           "Frosch hüpft ins Saxophon", "Ober serviert Salat", "Familie fährt heim")

dat_text_criteria$content <- rep(texts,1)


# lmer Ansatz
library(lme4)
library(car)

dat_lmer <- dat[dat$image_type != "Bridging" & dat$filter == 1, 
                c("vt", "participant", "condition", "image_type", "story")]

mod <- lmer(log(vt) ~ condition * image_type + 
              (condition | participant) + 
              (condition | story), 
              data = dat_lmer, REML = FALSE)

summary(mod)
Anova(mod)

difflsmeans(mod, test.effs = "condition:image_type", adjust = "tukey")

# Plot

dat_plot <- 
  ddply(dat[dat$filter == 1,],
        .(condition, image_type), 
        summarise,
        mean_vt = mean(vt), se_vt = se(vt), sd_vt = sd(vt))

pd <- position_dodge(0)

plot_mask_modality <- 
  ggplot(dat_plot, aes(x = image_type, y = mean_vt, fill = condition)) +
  geom_point( aes(color = condition), position = pd) +
  geom_line(aes(group = condition, color = condition), position = pd) +
  geom_errorbar(aes(ymax = mean_vt + se_vt, ymin = mean_vt - se_vt, color = condition), width =.2) +
  theme_bw(base_size = 16)  +
  theme(legend.title=element_blank()) +
  theme(legend.position = "top") +
  ylab("Viewing Time [sec]") +
  xlab("Image Sequence") +
  coord_cartesian(ylim = c(1,4.5))+
  scale_colour_manual(values=c("#009E73", "#E69F00", "#56B4E9"))+
  labs(title="Experiment 3")


ggsave("modality_mask.pdf", plot = plot_mask_modality, width = 15, height = 10, units = "cm")

grid.arrange(plot_modality,plot_mask,plot_mask_modality, nrow = 1)


g <- arrangeGrob(plot_modality,plot_mask,nrow = 1)
ggsave("modality_mask.tiff", g, width = 22, height = 11,units = "cm")





