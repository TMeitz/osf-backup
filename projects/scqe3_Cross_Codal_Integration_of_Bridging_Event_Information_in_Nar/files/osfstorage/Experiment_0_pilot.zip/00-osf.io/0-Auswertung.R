# Auswertung "informativeness" Experiment
# Rating Experiment as "pre-study" in the multi-codal paper
#
# last mod: 2019-07-14 mmh
#

library(tidyverse)
library(plyr)
library(sciplot)
library(ggplot2)
library(stringr)
library(PsychHelperFunctions)
library(BayesFactor)
library(ez)

#- Read data

paths <- dir(pattern = ".csv", full = T) 
dat <- data.frame()
for(i in seq_along(paths))
{
  print(paths[i])
  tmpdat <- read.csv(paths[i])
#  tmpdat <- tmpdat[, c(refcols)]
  if (length(dat) > 0 && !identical(names(dat),names(tmpdat)))
  {
    stop("Spaltennamen stimmen nicht - Fehler! Daten pruefen!")
  }
  dat <- rbind(dat,tmpdat)
  refcols <- names(dat)
}
# VP Variable faktorisieren
dat$participant <- factor(dat$participant)

# Bedingungsvariable "Bridging codality" spezifizieren
dat$bridging_codality <- "Picture"
dat[str_detect(dat$bridging,"text") == TRUE,]$bridging_codality <- "Text"
dat[dat$bridging == "pattern_1.png",]$bridging_codality <- "Blank"


# Wie viele VPn? -> 42
length(unique(dat$participant))

# Genauere Inspektion der Daten (es gibt einige VPn, für die keine Antworten protokolliert wurden)

dat_sum_responses <- 
  ddply(dat, .(participant, bridging_codality), summarize, n = sum(!is.na(slider.response)))

dat_sum_responses[dat_sum_responses$n == 0,]
# folgende VPn müssen ausgeschlossen werden, da für diese keine Daten protokolliert wurden: AILrC, OjxpE, ZXKMw

dat <- dat[dat$participant != "AILrC",]
dat <- dat[dat$participant != "OjxpE",]
dat <- dat[dat$participant != "ZXKMw",]

# Datenuebersicht

## NAs raus

dat <- dat[!is.na(dat$slider.response),]


# Mittleres Rating pro Bedingung 

dat_rating <- ddply(dat, .(bridging_codality), summarise, mean_rating = mean(slider.response), se_rating = se(slider.response))

ggplot(dat_rating, aes(x = bridging_codality, y = mean_rating, color = bridging_codality)) +
  geom_point(size = 3) +
  geom_errorbar(aes(ymin = mean_rating - se_rating, ymax = mean_rating + se_rating), size = 1, width = 0.4) +
  ylab("Informativeness Rating [1 ... 7]") +
  xlab("Bridging Event Codality") +
  coord_cartesian(ylim = c(1,7)) +
  scale_y_continuous(breaks = scales::pretty_breaks(n = 5)) +
  theme_bw(base_size = 20) +
  scale_colour_manual(values=c("#009E73", "#E69F00", "#56B4E9")) +
  theme(legend.position = "none")


# Inferenz Statistik

dat_aov <- ddply(dat, .(participant, bridging_codality),
                 summarize, 
                 mean_rating = mean(slider.response))

ezANOVA(data = dat_aov
        , dv = mean_rating
        , wid = participant
        , within = bridging_codality)

post_hoc_test <- pairwise.t.test(dat_aov$mean_rating, dat_aov$bridging_codality)
print(post_hoc_test, digits =3)


# Violin plot
data_summary <- function(x) {
  m <- mean(x)
  ymin <- m-se(x)
  ymax <- m+se(x)
  return(c(y=m,ymin=ymin,ymax=ymax))
}


ggplot(dat_aov, aes(x = bridging_codality, y = mean_rating)) +
  geom_violin() +
  geom_jitter(color = "grey", width = 0.2) +
  stat_summary(fun.data=data_summary) +
  theme_bw(base_size = 20) 



