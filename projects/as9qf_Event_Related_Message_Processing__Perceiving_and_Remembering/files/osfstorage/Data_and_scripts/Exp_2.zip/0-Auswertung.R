# Massive memory, cut detection
## last modification: 2015-10-08 mh

## Ausgangspunkt: Unterschiedliche Ergebnisse bei semantic massive memory visual only und audiovisual
## Hypothesen: Schnitte werden bei audiovisual schlechter und wenn, dann langsamer erkannt als bei visual only.

library(ggplot2)
library(lme4)
library(sciplot)
library(stringr)
library(plyr)
library(ez)
library(tidyr)
library(readr)

# ezWrapper einlesen

ezANOVA.pes <- function (ezANOVAResult)
{
  if (is.null(ezANOVAResult$ANOVA$SSn) | is.null(ezANOVAResult$ANOVA$SSd))
  {
    stop("ezANOVA muss mit dem Parameter 'detailed=T' ausgeführt werden.")
  }
  
  ezANOVAResult$ANOVA$pes <- ezANOVAResult$ANOVA$SSn/(ezANOVAResult$ANOVA$SSn+ezANOVAResult$ANOVA$SSd)
  
  return(ezANOVAResult)
}

# Daten einlesen
wd <- getwd()

paths <- dir(path = wd, pattern = ".csv", full = T) 
paths
paths <- paths[c(16,18:26,33:46)]   #- nur VP >= 20 einlesen, VP 50 war mh!
dat.raw <- lapply(paths, read.csv)

# Generate data frame 
dat <- data.frame(dat.raw[1])

for (i in 2:length(dat.raw))
{
  dat <- rbind(dat,data.frame(dat.raw[i]))
}

dat <- dat[!is.na(dat$vp),]

# Schnittzeitpunkte einlesen
dat_cut <- read.csv("cut_detection_time_points.csv")

tmp <- merge(dat,dat_cut,all=T)
dat <- dat[!is.na(dat$expName),]
dat <- tmp

# Alle NAs in Reaktionszeiten durch 0 ersetzen
dat[is.na(dat$key_resp_5.rt),]$key_resp_5.rt  <- 0

unique(dat$participant)

# Wie viele trials in den Bedingungen?

xtabs(session/24~stimulustype,dat)

# Misses (wie oft wurde ein Filmschnitt verpasst)
dat$miss <- NA
dat[dat$key_resp_5.keys!="space",]$miss <- 1
dat[dat$key_resp_5.keys=="space",]$miss <- 0

aggregate(miss~sound+stimulustype,dat,sum)
aggregate(miss~sound+stimulustype,dat[dat$stimulustype!="Controll",],mean)

dat_agg <- aggregate(miss~participant+sound+stimulustype,dat[dat$stimulustype!="Controll",],mean)
summary(aov(miss~sound*stimulustype+Error(factor(participant)/(sound*stimulustype)),data=dat_agg))

ezANOVA(
  data=dat_agg,
  within=.(sound,stimulustype),
  dv=miss,
  wid=participant
 )

res <- ezANOVA(
          data=dat_agg,
          within=.(sound,stimulustype),
          dv=miss,
          wid=participant,
          detailed=T
)

ezANOVA.pes(res)

dat_agg_PC <- dat_agg

qplot(stimulustype,miss,color=sound,data=dat_agg,stat="summary",xlab="Dimension Change",ylab="Proportion of Missed Filmic Cuts",) + 
  stat_summary(fun.y=mean,  geom="point", size = 3) +
  stat_summary(fun.data=mean_se, geom="errorbar",mult=1,width=.3)+
  scale_colour_manual(values = c("blue","red"))


# Wie oft gedrückt, wenn kein Schnitt? (in ca. 15% der Durchgänge)

aggregate(miss~sound+stimulustype,dat,mean)
aggregate(miss~sound+stimulustype,dat,sd)

# Reaktionszeiten
# Differenz berechnen

dat$diff <- dat$key_resp_5.rt - dat$cut_sec

plot(density(dat[dat$diff>0,]$diff))

# Wie viele negative RTs? Bedeutet, dass VP vor Schnitt gedrückt haben?

aggregate(diff~1,dat[dat$miss==0&dat$stimulustype!="Controll"&dat$diff < 0,],length)

1259/length(dat[dat$miss==0&dat$stimulustype!="Controll",]$diff)

aggregate(diff~1,dat[dat$miss==0&dat$stimulustype!="Controll"&dat$diff > 0,],length)
aggregate(diff~stimulustype+sound,dat[dat$miss==0&dat$stimulustype!="Controll"&dat$diff > 0,],mean)

dat_agg <- aggregate(diff~stimulustype+sound+participant,dat[dat$miss==0&dat$stimulustype!="Controll"&dat$diff > 0,],mean)
aggregate(diff~stimulustype+sound,dat[dat$miss==0&dat$stimulustype!="Controll"&dat$diff > 0,],mean)

# PROBLEM: Nicht alle VPn haben Werte in allen Zellen (VP 23, 29 und 41 müssen ausgeschlossen werden)
xtabs(~participant,dat_agg)

dat_agg <- dat_agg[dat_agg$participant!=23,]
dat_agg <- dat_agg[dat_agg$participant!=29,]
dat_agg <- dat_agg[dat_agg$participant!=41,]

summary(aov(diff~sound*stimulustype+Error(factor(participant)/(sound*stimulustype)),dat_agg))


res <- ezANOVA(
  data=dat_agg,
  within=.(sound,stimulustype),
  dv=diff,
  wid=participant,
  detailed = T
)

ezANOVA.pes(res)

qplot(stimulustype,diff,color=sound,data=dat_agg,stat="summary",xlab="Dimension Change",ylab="Cut Detection Time [sec]") + 
  stat_summary(fun.y=mean,  geom="point", size = 3) +
  stat_summary(fun.data=mean_se, geom="errorbar",mult=1,width=.3)+
  scale_colour_manual(values = c("blue","red"))

# Effektstärke berechnen

ddply(dat_agg,.(stimulustype),summarize,mean_diff=mean(diff),sd_diff=sd(diff))
sd(dat_agg$diff)

cohen_d <- function(mean1,mean2,pooled_sd)
{
  (mean1-mean2)/pooled_sd
}

cohen_f <- function(cohen_d)
{
  cohen_d*.5
}

cohen_d(0.7218441,0.7028057,0.1719762)
cohen_f(0.1107037)



dat_agg_PC$stimulustype <- factor(dat_agg_PC$stimulustype,labels=c("Between Scene","Within Scene"))
dat_agg_PC$sound <- factor(dat_agg_PC$sound,labels=c("Audiovisual","Visual"))
dat_agg$stimulustype <- factor(dat_agg$stimulustype,labels=c("Between Scene","Within Scene"))

library(sciplot)
par(mfrow=c(1,2))
bargraph.CI.within(stimulustype,miss,group=sound,data=dat_agg_PC,ylim=c(0,.5),
            xlab="Change",ylab="Proportion Missed Filmic Cuts",legend=T,x.leg=1,sid=participant)
bargraph.CI.within(stimulustype,diff,group=sound,data=dat_agg,,ylim=c(0,1),xlab="Change",ylab="Cut Detection Time [sec]",sid=participant)


# Abbildung für Psychonomic 2014

dat_agg_PC$stimulustype <- factor(dat_agg_PC$stimulustype,labels=c("Between Scene","Within Scene"))
dat_agg_PC$sound <- factor(dat_agg_PC$sound,labels=c("Audiovisual","Visual"))
dat_agg$stimulustype <- factor(dat_agg$stimulustype,labels=c("Between Scene","Within Scene"))
dat_agg$sound <- factor(dat_agg$sound,labels=c("Audiovisual","Visual"))

library(sciplot)
par(mfrow=c(1,2))
bargraph.CI.within(stimulustype,miss,group=sound,data=dat_agg_PC,ylim=c(0,.5),
                   xlab="Change",ylab="Proportion Missed Filmic Cuts",legend=T,x.leg=1,sid=participant)
bargraph.CI.within(stimulustype,diff,group=sound,data=dat_agg,,ylim=c(0,1),xlab="Change",ylab="Cut Detection Time [sec]",sid=participant)

par(mfrow=c(1,2))
bargraph.CI.within(sound,miss,group=stimulustype,data=dat_agg_PC,ylim=c(0,.5),
                   xlab="Modality",ylab="Proportion Missed Filmic Cuts",legend=T,x.leg=1,y.leg=.45,sid=participant)
text(2,.45,"Change")
bargraph.CI.within(sound,diff,group=stimulustype,data=dat_agg,,ylim=c(0,1),xlab="Modality",ylab="Cut Detection Time [sec]",sid=participant)

# Relation Schnitt zur Gesamtlaenge, gibt es einen Unterschied zwischen between und within scene cuts?

dat_cut$condition <- str_extract(dat_cut$movie,"[A-Z]")

ddply(dat_cut[dat_cut$condition!="C",],.(condition),summarize,mean_cut_sec=mean(cut_sec),sd_cut_sec=sd(cut_sec))
t.test(cut_sec~condition,data=dat_cut[dat_cut$condition!="C",],paired=F)


# Export data for JASP analysis
dat_agg$Change <- str_replace(dat_agg$stimulustype," ","_")
dat_agg$Modality <- dat_agg$sound
dat_agg$stimulustype <- NULL
dat_agg$sound <- NULL
dat_jasp <- dat_agg %>% unite(Change_Modality,Change,Modality) %>% spread(Change_Modality,diff) 

write_csv(dat_jasp,"dat_jasp.csv")
